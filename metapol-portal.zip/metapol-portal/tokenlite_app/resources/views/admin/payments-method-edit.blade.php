@extends('layouts.admin')
@section('title', 'Edit Payment Method')

@section('content')
{{ $method }}
@endsection
